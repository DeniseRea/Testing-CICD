/**
 * Función para sumar dos números
 * @param {number} a - Primer número
 * @param {number} b - Segundo número
 * @returns {number} La suma de a y b
 */
export function sum(a, b) {
  return a + b;
}
